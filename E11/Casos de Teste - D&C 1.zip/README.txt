Arquivo zip gerado em: 10/05/2022 08:36:42 
Este arquivo contém os casos de teste cadastrados até o momento, disponibilizado pelo professor aos alunos.
Exercício: D&C 1