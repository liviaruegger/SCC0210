Arquivo zip gerado em: 10/07/2022 19:46:53 
Este arquivo contém os casos de teste cadastrados até o momento, disponibilizado pelo professor aos alunos.
Exercício: JOG 2