Arquivo zip gerado em: 10/04/2022 18:05:21 
Este arquivo contém os casos de teste cadastrados até o momento, disponibilizado pelo professor aos alunos.
Exercício: STL 4