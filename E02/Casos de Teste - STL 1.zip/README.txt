Arquivo zip gerado em: 25/03/2022 16:13:55 
Este arquivo contém os casos de teste cadastrados até o momento, disponibilizado pelo professor aos alunos.
Exercício: STL 1