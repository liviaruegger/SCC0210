Arquivo zip gerado em: 24/07/2022 21:49:35 
Este arquivo contém os casos de teste cadastrados até o momento, disponibilizado pelo professor aos alunos.
Exercício: GEO 1