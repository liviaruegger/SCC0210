Arquivo zip gerado em: 25/07/2022 16:18:14 
Este arquivo contém os casos de teste cadastrados até o momento, disponibilizado pelo professor aos alunos.
Exercício: GEO 2