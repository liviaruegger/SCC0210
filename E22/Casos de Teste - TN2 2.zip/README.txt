Arquivo zip gerado em: 11/06/2022 16:30:38 
Este arquivo contém os casos de teste cadastrados até o momento, disponibilizado pelo professor aos alunos.
Exercício: TN2 2