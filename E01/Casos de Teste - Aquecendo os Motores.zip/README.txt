Arquivo zip gerado em: 22/03/2022 18:46:52 
Este arquivo contém os casos de teste cadastrados até o momento, disponibilizado pelo professor aos alunos.
Exercício: Aquecendo os Motores