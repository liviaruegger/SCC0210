Arquivo zip gerado em: 11/06/2022 15:34:02 
Este arquivo contém os casos de teste cadastrados até o momento, disponibilizado pelo professor aos alunos.
Exercício: TN2 1