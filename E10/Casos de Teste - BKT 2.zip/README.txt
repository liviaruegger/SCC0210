Arquivo zip gerado em: 07/05/2022 23:00:56 
Este arquivo contém os casos de teste cadastrados até o momento, disponibilizado pelo professor aos alunos.
Exercício: BKT 2